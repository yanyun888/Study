//main函数原型的使用
#include <stdio.h>

int main(int argc,char* argv[],char* envp[])
{
	printf("argc = %d\n",argc);
	int i = 0;
	for(i = 0; i < argc; i++)
	{
		printf("argv[%d] = %s\n",i,argv[i]);
	}

	printf("------------------------\n");
	extern char** environ;
	printf("environ = %p,envp = %p\n",environ,envp); //地址是相同的
	return 0;
}





