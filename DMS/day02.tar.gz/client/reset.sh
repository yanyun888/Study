#!/bin/bash
rm -rf wtmpx.2015*
rm -rf *.dat
cp wtmpx.bak wtmpx
exit 0
