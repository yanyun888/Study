//错误编号和错误信息
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>

int main(void)
{
	printf("errno = %d\n",errno);
	printf("%d对应的错误信息是:%s\n",errno,strerror(errno));

	//1.打开文件
	FILE* fp = fopen("/etc/passwdd","r");
	if(NULL == fp)
	{
		printf("打开文件失败\n");
		printf("errno = %d\n",errno);
		printf("%d对应的错误信息是:%s\n",errno,strerror(errno));
		perror("fopen");
		printf("%m\n");
		//return -1;
	}
	//printf("文件打开成功\n");
	//2.关闭文件
	//fclose(fp);

	printf("-------------------------\n");
	//练习：使用只写的方式打开文件/etc/passwd,并且使用三种方法打印错误信息
	fp = fopen("/etc/passwd","w");
	if(NULL == fp)
	//if(0 != errno)
	{
		printf("errno = %d\n",errno);
		printf("%d对应的错误信息是：%s\n",errno,strerror(errno));
		perror("fopen");
		printf("%m\n");
	}
	
	return 0;
}





