//遍历环境表中所有的内容
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
	//外部变量的声明
	extern char** environ;
	//指定环境表首地址的替身
	char** ppc = environ;
	while(*ppc != NULL)
	{
		printf("%s\n",*ppc);
		//指向下一个环境变量
		ppc++;
	}
	
	printf("-----------------------\n");
	//练习：将环境表中名字为SHELL的环境变量值取出来放到自定义字符数组buf中，打印
	ppc = environ;
	char buf[20] = {0};
	while(*ppc != NULL)
	{
		//比较前5个字符是否相等
		if(!strncmp(*ppc,"SHELL",5))
		{
			//砍掉前6个字节,复制后面的内容
			strcpy(buf,*ppc+6);
			break;
		}
		//指向下一个
		ppc++;
	}
	printf("buf = %s\n",buf);// /bin/bash
	return 0;
}





